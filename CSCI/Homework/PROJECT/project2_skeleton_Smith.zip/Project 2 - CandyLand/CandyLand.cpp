#include <iostream>
#include <fstream>
#include <sstream>
#include "CandyLand.h"

using namespace std;

struct Character
{
    string charactername;
    int stamina;
    int gold;
    Candy character_inventory[];

};

CandyLand:: startGame() // put the functions of the game within the setup game
{
    displayBoard();
    setupGame();
}


void CandyLand:: setupGame()
{
    loadCandies();
    loadMinigames();
    loadCharacters();
}

void CandyLand::loadCandies()
{
    //initialize an array of all the available candies
    Candy available_candies[11];

}

void CanyLand::loadMinigames(int gamechoice)
{
    //build a switch case for each of the minigames
    cin << gamechoice
    switch(gamechoice)
    1: riddles function


}

void CandyLand::loadCharacters()
{
    //build a struct for each of the characters then apply each character to the player profile

    /*struct Character
{
    string charactername;
    int stamina;
    int gold;
    Candy character_inventory[];

};
*/

}

void displayMainMenu()
{
    int menu_choice;
    cout << "[PlayerName]'s Turn" << endl;
    Board::displayBoard();
    cout << "1) Draw a card" << endl;
    cout << "2) Use Candy" << endl;
    cout << "3) Show Player Stats" << endl;
    cin >> menu_choice;
    switch (menu_choice)
    {
    case 1:
        /* code */
        break;
    case 2:
        /* code */
        break;
    case 3:
        /* code */
        break;
    
    default:
        break;
    }

}

void CandyLand:: gameLoop()
{
    // Loop while neither player is at the castle at location 83
    displayMainMenu();
}

void CandyLand:: candyStore()
{
    // Copy Paste the candystore function
}

Card CandyLand:: drawCard()
{
    // min -> 1 and max -> 3
    // 1 -> pink
    // 2 -> green
    // 3 -> blue
    /*
    Create an instance of Card Struct
    assign it a random number
        if divisible by 1, 2, or 3, select from colors above
    Then generate a random number using rand()
    If divisible by 4, (AKA 1 in 4) then update bool isDouble to true for that card

    Update Player location
    */
}

void CandyLand:: calamity()
{
    //set up each calamity and randomly select 
}