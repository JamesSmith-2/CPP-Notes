#ifndef CANDYLAND_H
#define CANDYLAND_H
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;


/**
 * \CandyLand
struct -> candy, card, treasure, 
class -> Player, Board, Tile, Store, Riddles, CandyLand, CandyStore, 

Events, Riddles/Puzzle (struct / class), 
*/

struct Candy
{
    string name;
    string description;
    string effect_type;
    string effect_value;
    string type;
    double price;
}

struct Card
{
    string color;
    bool is_double;
}

struct Treasure
{
    int chance;
    int type;
    
}

class CandyLand
{

    public:

        void startGame(); // leave this public so that the user can only start the game, then the game runs itself

    private:
        
        void setupGame(); // board and tiles

        void setupBoard();
        void loadCandies();
        void loadMinigames();
        void loadCharacters();
        Card drawCard();

        void gameLoop();
        void calamity();
};
#endif

#ifndef RIDDLES_H
#define RIDDLES_H

class Riddles
{
    public:
    

    private:
    string riddle_answer;
    string riddle_text;

};
#endif



getColorTile()

/**
 * CandyLand
struct -> candy, card, treasure, 
class -> Player, Board, Tile, Store, Riddles, CandyLand, CandyStore, 

Events, Riddles/Puzzle (struct / class), 
 * 0. Setup Game
 *  setup the board -> 83 tiles
 *  place candystores
 *  place special tiles
 *  ...

 * 1. load available candy from file -> candystore, candyland, 
 * 2. Visit candystore -> Board, Candyland
 * 3. Load Charaacters from file
 * 4. Choose a character
 * 5. Choose number of players
 * 
*/



// min -> 1 and max -> 3
// 1 -> pink
// 2 -> green
// 3 -> blue

/**
 * 1 -> 27 : pink tile
 * 28 -> 53 : blue tile
 * 54 -> 82 : green tile
*/